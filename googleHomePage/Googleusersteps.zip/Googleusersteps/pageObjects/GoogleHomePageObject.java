package Googleusersteps.pageObjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class GoogleHomePageObject extends BasePageObject{
    protected WebDriver myDriver;

    @FindBy(how = How.XPATH, using = "//div[@id ='hplogo']")
    private WebElement doddle;

    @FindBy(how = How.NAME, using = "q")
    private WebElement searchBox;

    @FindBy(how = How.NAME, using = "btnI")
    private WebElement feelingLuckyButton;

    @FindBy(how = How.NAME, using = "btnK")
    private WebElement searchInGoogleButton;

    public GoogleHomePageObject(WebDriver Driver){
        super(Driver,Driver.getCurrentUrl());
    }

    public void clickOnSearchInGoogleButton(){
        this.searchInGoogleButton.click();
    }

    public void clickOnFeelingLuckyButton(){
        this.feelingLuckyButton.click();
    }

    public void clickOnDoodle(){

    }

    public void sendKeysInSearchBox(String searchText){
        this.searchBox.clear();
        this.searchBox.sendKeys(searchText, Keys.ENTER);
    }

    @Override
    public boolean isLoaded() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.visibilityOf(doddle));
            System.out.println("Cargo la página home de google");
            return true;
        } catch (RuntimeException exception) {
            System.out.println("Error: Pagina no Cargo " + exception);
            //logger.error(exception);
            return false;
        }
    }
}