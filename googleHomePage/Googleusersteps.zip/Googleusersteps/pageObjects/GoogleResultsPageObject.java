package Googleusersteps.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class GoogleResultsPageObject extends BasePageObject {


    @FindBy(how = How.ID, using = "result-stats")
    private WebElement resultStats;

    @FindBy(how = How.XPATH, using = "//div[@id='search']//div[@class='g']//h3[not(ancestor::div[@class='related-question-pair'])]")
    private List<WebElement> results;

    @FindBy(how = How.NAME, using = "q")
    private WebElement searchBox;

    @FindBy(how = How.XPATH, using = "//form[@name='f']//button[@type='submit']")
    private WebElement searchButton;

    public GoogleResultsPageObject(WebDriver driver, String baseURL) {
        super(driver,driver.getCurrentUrl());
    }

    public void clickOnSearchButton(){
        this.searchButton.click();
    }

    public void sendKeysInSearchBox(String searchText){
        this.searchBox.clear();
        this.searchBox.sendKeys(searchText);
    }

    public List<WebElement> getResults(){

        return this.results;
    }

    @Override
    public boolean isLoaded() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.visibilityOf(resultStats));
            System.out.println("Cargo la página de resultados");
            return true;
        } catch (RuntimeException exception) {
            System.out.println("Error: Pagina no Cargo " + exception);
            //logger.error(exception);
            return false;
        }
    }
}
